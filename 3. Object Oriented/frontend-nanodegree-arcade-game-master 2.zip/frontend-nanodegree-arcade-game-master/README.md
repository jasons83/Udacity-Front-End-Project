This is my project for Udacity Fron-End Nanodegree Part 2

Instalation

1. Download the file and open the Zip
2. Navigate to where you unzipped the file
3. Locate index.html and opent the file

Gameplay

1. One the page loads, you could move the character with arow keys
2. Your main character is the bug
3. Reach the blue water without to getting hit by the child boy

Enjoy the game!
