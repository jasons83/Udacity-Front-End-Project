# Memory Game Project

## Table of Contents

* [How To Play](#How To Play)
* [Rules](#Rules)

## How To Play

1. Download or clone the file to you machine.
2. Extract the .zip file
3. Open index.html in your browser. 

## Rules
1. Match cards with identical picture by clicking on them.
2. Your moves are counted out as you proceed the game.
3. The following are the scoring mechanism//
20 below gives you 5 star
25 below gives you 4 star
30 below gives you 3 star
35 below gives you 2 star
40 below gives you 1 star
4. There will be a timer that count how long you played the game! Try to beat it
6. You can  restart the game at any stage by clicking the restart button.